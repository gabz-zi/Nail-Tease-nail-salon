package com.nailSalon.model.entity;

public enum Category {
    GELISH, GEL, PEDICURE, THERAPY
}
