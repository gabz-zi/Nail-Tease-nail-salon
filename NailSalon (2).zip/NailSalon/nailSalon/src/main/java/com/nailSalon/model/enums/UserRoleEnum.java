package com.nailSalon.model.enums;

public enum UserRoleEnum {
    OWNER, MANAGER, EMPLOYEE, USER
}
