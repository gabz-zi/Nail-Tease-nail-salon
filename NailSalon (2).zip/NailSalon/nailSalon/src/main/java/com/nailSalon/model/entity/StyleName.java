package com.nailSalon.model.entity;

public enum StyleName {
    IMPRESSIONISM, ABSTRACT, EXPRESSIONISM, SURREALISM, REALISM
}
